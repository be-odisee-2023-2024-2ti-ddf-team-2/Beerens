package org.example.beerens_autosoort;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutosoortApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutosoortApplication.class, args);
    }
}